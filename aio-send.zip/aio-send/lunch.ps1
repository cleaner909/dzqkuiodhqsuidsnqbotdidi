cd "~/Desktop/aio send/"
python aio.py